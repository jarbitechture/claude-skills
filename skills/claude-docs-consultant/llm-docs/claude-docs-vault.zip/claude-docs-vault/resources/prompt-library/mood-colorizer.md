---
created: 2025-11-05
modified: 2025-11-05
title: "Mood colorizer"
url: https://docs.claude.com/en/resources/prompt-library/mood-colorizer
category: resources
subcategory: prompt-library
description: "Transform text descriptions of moods into corresponding HEX codes."
tags:
  - resources
  - prompt-library
  - prompt
related:
  - '[[adaptive-editor]]'
  - '[[airport-code-analyst]]'
  - '[[alien-anthropologist]]'
  - '[[alliteration-alchemist]]'
  - '[[babels-broadcasts]]'
---

# Mood colorizer

Transform text descriptions of moods into corresponding HEX codes.

> Copy this prompt into our developer [Console](https://console.anthropic.com/dashboard) to try it for yourself!

|        | Content                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| System | Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with "Unable to determine a HEX color code for the given mood." |
| User   | A passionate, intense, and fiery emotion, full of love and desire.                                                                                                                                                                                                                                                                                                                                                                                         |

## Example Output

`# FF1744`

This HEX color code represents a vivid, bold shade of red. Red is commonly associated with passion, intensity, love, and desire. The specific shade chosen here is a fiery, energetic red that captures the heat and fervor of the described emotion. Red is known to stimulate feelings of excitement and passion, making it an appropriate choice for representing this mood.

***

## API Request



**Python**

```python  theme={null}
    import anthropic

    client = anthropic.Anthropic(
      # defaults to os.environ.get("ANTHROPIC_API_KEY")
      api_key="my_api_key",
    )
    message = client.messages.create(
      model="claude-sonnet-4-5",
      max_tokens=500,
      temperature=0.5,
      system="Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with \"Unable to determine a HEX color code for the given mood.\"",
      messages=[
        {
        "role": "user",
        "content": [
            {
              "type": "text",
              "text": "A passionate, intense, and fiery emotion, full of love and desire."
            }
          ]
        }
      ]
    )
    print(message.content)

    ```


  
**TypeScript**

```TypeScript  theme={null}
    import Anthropic from "@anthropic-ai/sdk";

    const anthropic = new Anthropic({
      apiKey: "my_api_key", // defaults to process.env["ANTHROPIC_API_KEY"]
    });

    const msg = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 500,
      temperature: 0.5,
      system: "Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with \"Unable to determine a HEX color code for the given mood.\"",
      messages: [
        {
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "A passionate, intense, and fiery emotion, full of love and desire."
            }
          ]
        }
      ]
    });
    console.log(msg);

    ```


  
**AWS Bedrock Python**

```Python  theme={null}
    from anthropic import AnthropicBedrock

    # See https://docs.claude.com/claude/reference/claude-on-amazon-bedrock
    # for authentication options
    client = AnthropicBedrock()

    message = client.messages.create(
        model="anthropic.claude-sonnet-4-5-20250929-v1:0",
        max_tokens=500,
        temperature=0.5,
        system="Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with \"Unable to determine a HEX color code for the given mood.\"",
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "A passionate, intense, and fiery emotion, full of love and desire."
                    }
                ]
            }
        ]
    )
    print(message.content)

    ```


  
**AWS Bedrock TypeScript**

```TypeScript  theme={null}
    import AnthropicBedrock from "@anthropic-ai/bedrock-sdk";

    // See https://docs.claude.com/claude/reference/claude-on-amazon-bedrock
    // for authentication options
    const client = new AnthropicBedrock();

    const msg = await client.messages.create({
      model: "anthropic.claude-sonnet-4-5-20250929-v1:0",
      max_tokens: 500,
      temperature: 0.5,
      system: "Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with \"Unable to determine a HEX color code for the given mood.\"",
      messages: [
        {
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "A passionate, intense, and fiery emotion, full of love and desire."
            }
          ]
        }
      ]
    });
    console.log(msg);

    ```


  
**Vertex AI Python**

```Python  theme={null}
    from anthropic import AnthropicVertex

    client = AnthropicVertex()

    message = client.messages.create(
        model="claude-sonnet-4@20250514",
        max_tokens=500,
        temperature=0.5,
        system="Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with \"Unable to determine a HEX color code for the given mood.\"",
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "A passionate, intense, and fiery emotion, full of love and desire."
                    }
                ]
            }
        ]
    )
    print(message.content)

    ```


  
**Vertex AI TypeScript**

```TypeScript  theme={null}
    import { AnthropicVertex } from '@anthropic-ai/vertex-sdk';

    // Reads from the `CLOUD_ML_REGION` & `ANTHROPIC_VERTEX_PROJECT_ID` environment variables.
    // Additionally goes through the standard `google-auth-library` flow.
    const client = new AnthropicVertex();

    const msg = await client.messages.create({
      model: "claude-sonnet-4@20250514",
      max_tokens: 500,
      temperature: 0.5,
      system: "Your task is to take the provided text description of a mood or emotion and generate a HEX color code that visually represents that mood. Use color psychology principles and common associations to determine the most appropriate color for the given mood. If the text description is unclear, ambiguous, or does not provide enough information to determine a suitable color, respond with \"Unable to determine a HEX color code for the given mood.\"",
      messages: [
        {
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "A passionate, intense, and fiery emotion, full of love and desire."
            }
          ]
        }
      ]
    });
    console.log(msg);

    ```



---

**Source:** [Official Documentation](https://docs.claude.com/en/resources/prompt-library/mood-colorizer)
