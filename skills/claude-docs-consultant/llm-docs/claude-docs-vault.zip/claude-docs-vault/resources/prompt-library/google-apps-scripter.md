---
created: 2025-11-05
modified: 2025-11-05
title: "Google apps scripter"
url: https://docs.claude.com/en/resources/prompt-library/google-apps-scripter
category: resources
subcategory: prompt-library
description: "Generate Google Apps scripts to complete tasks based on user requirements."
tags:
  - resources
  - prompt-library
  - prompt
related:
  - '[[adaptive-editor]]'
  - '[[airport-code-analyst]]'
  - '[[alien-anthropologist]]'
  - '[[alliteration-alchemist]]'
  - '[[babels-broadcasts]]'
---

# Google apps scripter

Generate Google Apps scripts to complete tasks based on user requirements.

> Copy this prompt into our developer [Console](https://console.anthropic.com/dashboard) to try it for yourself!

|      | Content                                                                                               |
| ---- | ----------------------------------------------------------------------------------------------------- |
| User | Write me a Google apps script that will translate all text in a Google Slides presentation to Korean. |

## Example Output

Here's a Google Apps Script that translates all the text in a Google Slides presentation to Korean:

```JavaScript  theme={null}
function translateSlidesToKorean() {
  var presentation = SlidesApp.getActivePresentation();
  var slides = presentation.getSlides();

  for (var i = 0; i < slides.length; i++) {
    var slide = slides[i];
    var pageElements = slide.getPageElements();

    for (var j = 0; j < pageElements.length; j++) {
      var pageElement = pageElements[j];

      if (pageElement.getPageElementType() === SlidesApp.PageElementType.SHAPE) {
        var shape = pageElement.asShape();
        if (shape.getText() !== null) {
          var text = shape.getText().asString();
          var translatedText = LanguageApp.translate(text, '', 'ko');
          shape.getText().setText(translatedText);
        }
      } else if (pageElement.getPageElementType() === SlidesApp.PageElementType.TABLE) {
        var table = pageElement.asTable();
        var numRows = table.getNumRows();
        var numColumns = table.getNumColumns();

        for (var row = 0; row < numRows; row++) {
          for (var col = 0; col < numColumns; col++) {
            var tableCell = table.getCell(row, col);
            var text = tableCell.getText().asString();
            var translatedText = LanguageApp.translate(text, '', 'ko');
            tableCell.getText().setText(translatedText);
          }
        }
      }
    }
  }
}
```

Here's how the script works:

1. The `translateSlidesToKorean()` function retrieves the active Google Slides presentation using `SlidesApp.getActivePresentation()`.

2. It gets all the slides in the presentation using the `getSlides()` method.

3. We iterate over each slide in the presentation.

4. For each slide, we retrieve all the page elements (shapes, text boxes, tables, etc.) using the `getPageElements()` method.

5. We iterate over each page element on the slide.

6. We check the type of the page element using `getPageElementType()`:

   * If the page element is a shape (`SlidesApp.PageElementType.SHAPE`), we get the text content of the shape using `getText().asString()`. We then translate the text to Korean using `LanguageApp.translate(text, '', 'ko')`, where `''` represents the source language (auto-detect) and `'ko'` represents the target language (Korean). Finally, we set the translated text back to the shape using `setText()`.
   * If the page element is a table (`SlidesApp.PageElementType.TABLE`), we iterate over each cell in the table and translate the text within each cell similarly to how we handle shapes.

7. The script continues to process all the page elements on each slide until all the text in the presentation has been translated to Korean.

{' '}

> [!note]
> **Note:** This script assumes that you have the necessary permissions to
>   access and modify the Google Slides presentation. Make sure you have the
>   required access rights before running the script.

Also, keep in mind that the translation is performed using the Google Translate
API, so the quality of the translation may vary depending on the complexity of
the text and the capabilities of the translation service.

***

## API Request



**Python**

```python  theme={null}
    import anthropic

    client = anthropic.Anthropic(
      # defaults to os.environ.get("ANTHROPIC_API_KEY")
      api_key="my_api_key",
    )
    message = client.messages.create(
      model="claude-sonnet-4-5",
      max_tokens=2000,
      temperature=0,
      messages=[
        {
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "Write me a Google apps script that will translate all text in a Google Slides presentation to Korean."
            }
          ]
        }
      ]
    )
    print(message.content)

    ```


  
**TypeScript**

```TypeScript  theme={null}
    import Anthropic from "@anthropic-ai/sdk";

    const anthropic = new Anthropic({
      apiKey: "my_api_key", // defaults to process.env["ANTHROPIC_API_KEY"]
    });

    const msg = await anthropic.messages.create({
      model: "claude-sonnet-4-5",
      max_tokens: 2000,
      temperature: 0,
      messages: [
        {
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "Write me a Google apps script that will translate all text in a Google Slides presentation to Korean."
            }
          ]
        }
      ]
    });
    console.log(msg);

    ```


  
**AWS Bedrock AI TypeScript**

```
    from anthropic import AnthropicBedrock

    # See https://docs.claude.com/claude/reference/claude-on-amazon-bedrock
    # for authentication options
    client = AnthropicBedrock()

    message = client.messages.create(
        model="anthropic.claude-sonnet-4-5-20250929-v1:0",
        max_tokens=2000,
        temperature=0,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Write me a Google apps script that will translate all text in a Google Slides presentation to Korean."
                    }
                ]
            }
        ]
    )
    print(message.content)

    ```


  
**AWS Bedrock AI Python**

```
    import AnthropicBedrock from "@anthropic-ai/bedrock-sdk";

    // See https://docs.claude.com/claude/reference/claude-on-amazon-bedrock
    // for authentication options
    const client = new AnthropicBedrock();

    const msg = await client.messages.create({
      model: "anthropic.claude-sonnet-4-5-20250929-v1:0",
      max_tokens: 2000,
      temperature: 0,
      messages: [
        {
          "role": "user",
          "content": [
            {
              "type": "text",
              "text": "Write me a Google apps script that will translate all text in a Google Slides presentation to Korean."
            }
          ]
        }
      ]
    });
    console.log(msg);

    ```


  
**Vertex AI Python**

```
    from anthropic import AnthropicVertex

    client = AnthropicVertex()

    message = client.messages.create(
        model="claude-sonnet-4@20250514",
        max_tokens=2000,
        temperature=0,
        messages=[
            {
                "role": "user",
                "content": [
                    {
                        "type": "text",
                        "text": "Write me a Google apps script that will translate all text in a Google Slides presentation to Korean."
                    }
                ]
            }
        ]
    )
    print(message.content)

    ```


  
**Vertex AI TypeScript**

```typescript  theme={null}
    import { AnthropicVertex } from '@anthropic-ai/vertex-sdk';

    // Reads from the `CLOUD_ML_REGION` & `ANTHROPIC_VERTEX_PROJECT_ID` environment variables.
    // Additionally goes through the standard `google-auth-library` flow.
    const client = new AnthropicVertex();

    const msg = await client.messages.create({
    model: "claude-sonnet-4@20250514",
    max_tokens: 2000,
    temperature: 0,
    messages: [
    {
    "role": "user",
    "content": [
    {
    "type": "text",
    "text": "Write me a Google apps script that will translate all text in a Google Slides presentation to Korean."
    }
    ]
    }
    ]
    });
    console.log(msg);

    ```



---

**Source:** [Official Documentation](https://docs.claude.com/en/resources/prompt-library/google-apps-scripter)
