---
created: 2025-11-05
modified: 2025-11-05
title: "Code clarifier"
url: https://docs.claude.com/en/resources/prompt-library/code-clarifier
category: resources
subcategory: prompt-library
description: "Simplify and explain complex code in plain language."
tags:
  - resources
  - prompt-library
  - prompt
related:
  - '[[adaptive-editor]]'
  - '[[airport-code-analyst]]'
  - '[[alien-anthropologist]]'
  - '[[alliteration-alchemist]]'
  - '[[babels-broadcasts]]'
---

# Code clarifier

Simplify and explain complex code in plain language.

> Copy this prompt into our developer [Console](https://console.anthropic.com/dashboard) to try it for yourself!

|        | Content                                                                                                                                                                                                                                                                                                                                                                                                                                                                                                    |
| ------ | ---------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| System | Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level. |
| User   | import random def bubble\*sort(arr): n = len(arr) for i in range(n-1): for j in range(n-i-1): if arr\[j] > arr\[j+1]: arr\[j], arr\[j+1] = arr\[j+1], arr\[j] return arr numbers = \[random.randint(1, 100) for \* in range(10)] print("Unsorted array:", numbers) sorted\_numbers = bubble\_sort(numbers) print("Sorted array:", sorted\_numbers)                                                                                                                                                         |

### Example Output

> This code demonstrates the implementation of the bubble sort algorithm, which is used to sort a list of numbers in ascending order. Let's break it down step by step:
>
> 1. The code starts by importing the 'random' module, which will be used to generate random numbers for the example.
>
> 2. The 'bubble\_sort' function is defined, which takes an array (list) of numbers as input. This function will perform the sorting operation.
>
> 3. Inside the 'bubble\_sort' function, the variable 'n' is assigned the length of the input array. This will be used to determine the number of iterations needed for sorting.
>
> 4. The first loop, controlled by the variable 'i', iterates 'n-1' times. This is because after 'n-1' passes, the largest number will be at the end of the array, so we don't need to compare it again.
>
> 5. The second loop, controlled by the variable 'j', iterates 'n-i-1' times. This is because after each pass, the largest number among the unsorted elements will be placed at the end, so we don't need to compare it in the next pass.
>
> 6. Inside the second loop, there is an if statement that compares adjacent elements in the array. If the element at index 'j' is greater than the element at index 'j+1', they are swapped. This ensures that the larger element moves towards the end of the array.
>
> 7. The swapping is done using the Python syntax 'arr\[j], arr\[j+1] = arr\[j+1], arr\[j]', which simultaneously assigns the values of 'arr\[j+1]' to 'arr\[j]' and 'arr\[j]' to 'arr\[j+1]'.
>
> 8. After all the iterations are complete, the sorted array is returned by the 'bubble\_sort' function.
>
> 9. In the example code, a list of 10 random numbers between 1 and 100 is generated using a list comprehension: '\[random.randint(1, 100) for \_ in range(10)]'. The underscore '\_' is used as a placeholder variable since we don't need the index values.
>
> 10. The unsorted array is printed to show the initial order of the numbers.
>
> 11. The 'bubble\_sort' function is called with the 'numbers' array as input, and the sorted array is stored in the 'sorted\_numbers' variable.
>
> 12. Finally, the sorted array is printed to display the numbers in ascending order.
>
> In simpler terms, imagine you have a list of numbers that are out of order. The bubble sort algorithm works by comparing each number with the one next to it, and if they are in the wrong order, it swaps them. This process is repeated multiple times until the entire list is sorted. It's like bubbles rising to the surface, with the larger numbers gradually moving towards the end of the list in each pass.

***

### API request

```python Python theme={null}
  import anthropic

  client = anthropic.Anthropic(
      # defaults to os.environ.get("ANTHROPIC_API_KEY")
      api_key="my_api_key",
  )
  message = client.messages.create(
      model="claude-sonnet-4-5",
      max_tokens=1000,
      temperature=0,
      system="Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level.",
      messages=[
          {
              "role": "user",
              "content": [
                  {
                      "type": "text",
                      "text": "import random\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n-1):\n        for j in range(n-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n\nnumbers = [random.randint(1, 100) for _ in range(10)]\nprint(\"Unsorted array:\", numbers)\nsorted_numbers = bubble_sort(numbers)\nprint(\"Sorted array:\", sorted_numbers)"
                  }
              ]
          }
      ]
  )
  print(message.content)

  ```

  ```typescript TypeScript theme={null}
  import Anthropic from "@anthropic-ai/sdk";

  const anthropic = new Anthropic({
    apiKey: "my_api_key", // defaults to process.env["ANTHROPIC_API_KEY"]
  });

  const msg = await anthropic.messages.create({
    model: "claude-sonnet-4-5",
    max_tokens: 1000,
    temperature: 0,
    system: "Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level.",
    messages: [
      {
        "role": "user",
        "content": [
          {
            "type": "text",
            "text": "import random\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n-1):\n        for j in range(n-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n\nnumbers = [random.randint(1, 100) for _ in range(10)]\nprint(\"Unsorted array:\", numbers)\nsorted_numbers = bubble_sort(numbers)\nprint(\"Sorted array:\", sorted_numbers)"
          }
        ]
      }
    ]
  });
  console.log(msg);

  ```

  ```python AWS Bedrock Python theme={null}
  from anthropic import AnthropicBedrock

  # See https://docs.claude.com/claude/reference/claude-on-amazon-bedrock
  # for authentication options
  client = AnthropicBedrock()

  message = client.messages.create(
      model="anthropic.claude-sonnet-4-5-20250929-v1:0",
      max_tokens=1000,
      temperature=0,
      system="Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level.",
      messages=[
          {
              "role": "user",
              "content": [
                  {
                      "type": "text",
                      "text": "import random\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n-1):\n        for j in range(n-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n\nnumbers = [random.randint(1, 100) for _ in range(10)]\nprint(\"Unsorted array:\", numbers)\nsorted_numbers = bubble_sort(numbers)\nprint(\"Sorted array:\", sorted_numbers)"
                  }
              ]
          }
      ]
  )
  print(message.content)

  ```

  ```typescript AWS Bedrock TypeScript theme={null}
  import AnthropicBedrock from "@anthropic-ai/bedrock-sdk";

  // See https://docs.claude.com/claude/reference/claude-on-amazon-bedrock
  // for authentication options
  const client = new AnthropicBedrock();

  const msg = await client.messages.create({
    model: "anthropic.claude-sonnet-4-5-20250929-v1:0",
    max_tokens: 1000,
    temperature: 0,
    system: "Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level.",
    messages: [
      {
        "role": "user",
        "content": [
          {
            "type": "text",
            "text": "import random\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n-1):\n        for j in range(n-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n\nnumbers = [random.randint(1, 100) for _ in range(10)]\nprint(\"Unsorted array:\", numbers)\nsorted_numbers = bubble_sort(numbers)\nprint(\"Sorted array:\", sorted_numbers)"
          }
        ]
      }
    ]
  });
  console.log(msg);

  ```

  ```python Vertex AI Python theme={null}
  from anthropic import AnthropicVertex

  client = AnthropicVertex()

  message = client.messages.create(
      model="claude-sonnet-4@20250514",
      max_tokens=1000,
      temperature=0,
      system="Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level.",
      messages=[
          {
              "role": "user",
              "content": [
                  {
                      "type": "text",
                      "text": "import random\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n-1):\n        for j in range(n-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n\nnumbers = [random.randint(1, 100) for _ in range(10)]\nprint(\"Unsorted array:\", numbers)\nsorted_numbers = bubble_sort(numbers)\nprint(\"Sorted array:\", sorted_numbers)"
                  }
              ]
          }
      ]
  )
  print(message.content)

  ```

  ```typescript Vertex AI TypeScript theme={null}
  import { AnthropicVertex } from '@anthropic-ai/vertex-sdk';

  // Reads from the `CLOUD_ML_REGION` & `ANTHROPIC_VERTEX_PROJECT_ID` environment variables.
  // Additionally goes through the standard `google-auth-library` flow.
  const client = new AnthropicVertex();

  const msg = await client.messages.create({
    model: "claude-sonnet-4@20250514",
    max_tokens: 1000,
    temperature: 0,
    system: "Your task is to take the code snippet provided and explain it in simple, easy-to-understand language. Break down the code's functionality, purpose, and key components. Use analogies, examples, and plain terms to make the explanation accessible to someone with minimal coding knowledge. Avoid using technical jargon unless absolutely necessary, and provide clear explanations for any jargon used. The goal is to help the reader understand what the code does and how it works at a high level.",
    messages: [
      {
        "role": "user",
        "content": [
          {
            "type": "text",
            "text": "import random\n\ndef bubble_sort(arr):\n    n = len(arr)\n    for i in range(n-1):\n        for j in range(n-i-1):\n            if arr[j] > arr[j+1]:\n                arr[j], arr[j+1] = arr[j+1], arr[j]\n    return arr\n\nnumbers = [random.randint(1, 100) for _ in range(10)]\nprint(\"Unsorted array:\", numbers)\nsorted_numbers = bubble_sort(numbers)\nprint(\"Sorted array:\", sorted_numbers)"
          }
        ]
      }
    ]
  });
  console.log(msg);

  ```

---

**Source:** [Official Documentation](https://docs.claude.com/en/resources/prompt-library/code-clarifier)
