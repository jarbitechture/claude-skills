---
created: 2025-11-05
modified: 2025-11-05
type: moc
category: resources
tags:
  - moc
  - resources
  - index
---

# Resources - Index

> [!abstract] Overview
> Index for **resources** documentation
> 66 pages across 2 sections

## General

- [[overview|null]]

## Prompt Library

- [[adaptive-editor|Adaptive editor]] - Rewrite text following user-given instructions, such as with a different tone, audience, or style.
- [[airport-code-analyst|Airport code analyst]] - Find and extract airport codes from text.
- [[alien-anthropologist|Alien anthropologist]] - Analyze human culture and customs from the perspective of an alien anthropologist.
- [[alliteration-alchemist|Alliteration alchemist]] - Generate alliterative phrases and sentences for any given subject.
- [[babels-broadcasts|Babel's broadcasts]] - Create compelling product announcement tweets in the world's 10 most spoken languages.
- [[brand-builder|Brand builder]] - Craft a design brief for a holistic brand identity.
- [[csv-converter|CSV converter]] - Convert data from various formats (JSON, XML, etc.) into properly formatted CSV files.
- [[career-coach|Career coach]] - Engage in role-play conversations with an AI career coach.
- [[cite-your-sources|Cite your sources]] - Get answers to questions about a document's content with relevant citations supporting the response.
- [[code-clarifier|Code clarifier]] - Simplify and explain complex code in plain language.
- [[code-consultant|Code consultant]] - Suggest improvements to optimize Python code performance.
- [[corporate-clairvoyant|Corporate clairvoyant]] - Extract insights, identify risks, and distill key information from long corporate reports into a single memo.
- [[cosmic-keystrokes|Cosmic Keystrokes]] - Generate an interactive speed typing game in a single HTML file, featuring side-scrolling gameplay and Tailwind CSS styling.
- [[culinary-creator|Culinary creator]] - Suggest recipe ideas based on the user's available ingredients and dietary preferences.
- [[data-organizer|Data organizer]] - Turn unstructured text into bespoke JSON tables.
- [[direction-decoder|Direction decoder]] - Transform natural language into step-by-step directions.
- [[dream-interpreter|Dream interpreter]] - Offer interpretations and insights into the symbolism of the user's dreams.
- [[efficiency-estimator|Efficiency estimator]] - Calculate the time complexity of functions and algorithms.
- [[email-extractor|Email extractor]] - Extract email addresses from a document into a JSON-formatted list.
- [[emoji-encoder|Emoji encoder]] - Convert plain text into fun and expressive emoji messages.
- [[ethical-dilemma-navigator|Ethical dilemma navigator]] - Help the user think through complex ethical dilemmas and provide different perspectives.
- [[excel-formula-expert|Excel formula expert]] - Create Excel formulas based on user-described calculations or data manipulations.
- [[function-fabricator|Function fabricator]] - Create Python functions based on detailed specifications.
- [[futuristic-fashion-advisor|Futuristic fashion advisor]] - Suggest avant-garde fashion trends and styles for the user's specific preferences.
- [[git-gud|Git gud]] - Generate appropriate Git commands based on user-described version control actions.
- [[google-apps-scripter|Google apps scripter]] - Generate Google Apps scripts to complete tasks based on user requirements.
- [[grading-guru|Grading guru]] - Compare and evaluate the quality of written texts based on user-defined criteria and standards.
- [[grammar-genie|Grammar genie]] - Transform grammatically incorrect sentences into proper English.
- [[hal-the-humorous-helper|Hal the humorous helper]] - Chat with a knowledgeable AI that has a sarcastic side.
- [[idiom-illuminator|Idiom illuminator]] - Explain the meaning and origin of common idioms and proverbs.
- [[interview-question-crafter|Interview question crafter]] - Generate questions for interviews.
- [[latex-legend|LaTeX legend]] - Write LaTeX documents, generating code for mathematical equations, tables, and more.
- [[lesson-planner|Lesson planner]] - Craft in depth lesson plans on any subject.
- [[master-moderator|Master moderator]] - Evaluate user inputs for potential harmful or illegal content.
- [[meeting-scribe|Meeting scribe]] - Distill meetings into concise summaries including discussion topics, key takeaways, and action items.
- [[memo-maestro|Memo maestro]] - Compose comprehensive company memos based on key points.
- [[mindfulness-mentor|Mindfulness mentor]] - Guide the user through mindfulness exercises and techniques for stress reduction.
- [[mood-colorizer|Mood colorizer]] - Transform text descriptions of moods into corresponding HEX codes.
- [[motivational-muse|Motivational muse]] - Provide personalized motivational messages and affirmations based on user input.
- [[neologism-creator|Neologism creator]] - Invent new words and provide their definitions based on user-provided concepts or ideas.
- [[pii-purifier|PII purifier]] - Automatically detect and remove personally identifiable information (PII) from text documents.
- [[perspectives-ponderer|Perspectives ponderer]] - Weigh the pros and cons of a user-provided topic.
- [[philosophical-musings|Philosophical musings]] - Engage in deep philosophical discussions and thought experiments.
- [[polyglot-superpowers|Polyglot superpowers]] - Translate text from any language into any language.
- [[portmanteau-poet|Portmanteau poet]] - Blend two words together to create a new, meaningful portmanteau.
- [[product-naming-pro|Product naming pro]] - Create catchy product names from descriptions and keywords.
- [[library|Prompt Library]]
- [[prose-polisher|Prose polisher]] - Refine and improve written content with advanced copyediting techniques and suggestions.
- [[pun-dit|Pun-dit]] - Generate clever puns and wordplay based on any given topic.
- [[python-bug-buster|Python bug buster]] - Detect and fix bugs in Python code.
- [[review-classifier|Review classifier]] - Categorize feedback into pre-specified tags and categorizations.
- [[riddle-me-this|Riddle me this]] - Generate riddles and guide the user to the solutions.
- [[sql-sorcerer|SQL sorcerer]] - Transform everyday language into SQL queries.
- [[sci-fi-scenario-simulator|Sci-fi scenario simulator]] - Discuss with the user various science fiction scenarios and associated challenges and considerations.
- [[second-grade-simplifier|Second-grade simplifier]] - Make complex text easy for young learners to understand.
- [[simile-savant|Simile savant]] - Generate similes from basic descriptions.
- [[socratic-sage|Socratic sage]] - Engage in Socratic style conversation over a user-given topic.
- [[spreadsheet-sorcerer|Spreadsheet sorcerer]] - Generate CSV spreadsheets with various types of data.
- [[storytelling-sidekick|Storytelling sidekick]] - Collaboratively create engaging stories with the user, offering plot twists and character development.
- [[time-travel-consultant|Time travel consultant]] - Help the user navigate hypothetical time travel scenarios and their implications.
- [[tongue-twister|Tongue twister]] - Create challenging tongue twisters.
- [[trivia-generator|Trivia generator]] - Generate trivia questions on a wide range of topics and provide hints when needed.
- [[tweet-tone-detector|Tweet tone detector]] - Detect the tone and sentiment behind tweets.
- [[vr-fitness-innovator|VR fitness innovator]] - Brainstorm creative ideas for virtual reality fitness games.
- [[website-wizard|Website wizard]] - Create one-page websites based on user specifications.

## All resources Pages

```dataview
TABLE description, subcategory
FROM #resources
WHERE type != "moc"
SORT file.name
```
