---
created: 2025-11-05
modified: 2025-11-05
type: moc
category: api
tags:
  - moc
  - api
  - index
---

# Api - Index

> [!abstract] Overview
> Index for **api** documentation
> 84 pages across 4 sections

## Admin Api

- [[create-workspace-member|Add Workspace Member]]
- [[archive-workspace|Archive Workspace]]
- [[create-invite|Create Invite]]
- [[create-workspace|Create Workspace]]
- [[delete-invite|Delete Invite]]
- [[delete-workspace-member|Delete Workspace Member]]
- [[get-api-key|Get API Key]]
- [[get-claude-code-usage-report|Get Claude Code Usage Report]] - Retrieve daily aggregated usage metrics for Claude Code users.
- [[get-cost-report|Get Cost Report]]
- [[get-invite|Get Invite]]
- [[get-me|Get Organization Info]]
- [[get-messages-usage-report|Get Usage Report for the Messages API]]
- [[get-user|Get User]]
- [[get-workspace|Get Workspace]]
- [[get-workspace-member|Get Workspace Member]]
- [[list-api-keys|List API Keys]]
- [[list-invites|List Invites]]
- [[list-users|List Users]]
- [[list-workspace-members|List Workspace Members]]
- [[list-workspaces|List Workspaces]]
- [[remove-user|Remove User]]
- [[update-api-key|Update API Keys]]
- [[update-user|Update User]]
- [[update-workspace|Update Workspace]]
- [[update-workspace-member|Update Workspace Member]]

## Agent Sdk

- [[overview|Agent SDK overview]] - Build custom AI agents with the Claude Agent SDK
- [[python|Agent SDK reference - Python]] - Complete API reference for the Python Agent SDK, including all functions, types, and classes.
- [[typescript|Agent SDK reference - TypeScript]] - Complete API reference for the TypeScript Agent SDK, including all functions, types, and interfaces.
- [[skills|Agent Skills in the SDK]] - Extend Claude with specialized capabilities using Agent Skills in the Claude Agent SDK
- [[custom-tools|Custom Tools]] - Build and integrate custom tools to extend Claude Agent SDK functionality
- [[permissions|Handling Permissions]] - Control tool usage and permissions in the Claude Agent SDK
- [[hosting|Hosting the Agent SDK]] - Deploy and host Claude Agent SDK in production environments
- [[mcp|MCP in the SDK]] - Extend Claude Code with custom tools using Model Context Protocol servers
- [[modifying-system-prompts|Modifying system prompts]] - Learn how to customize Claude's behavior by modifying system prompts using three approaches - output styles, systemPrompt with append, and custom system prompts.
- [[plugins|Plugins in the SDK]] - Load custom plugins to extend Claude Code with commands, agents, skills, and hooks through the Agent SDK
- [[sessions|Session Management]] - Understanding how the Claude Agent SDK handles sessions and session resumption
- [[slash-commands|Slash Commands in the SDK]] - Learn how to use slash commands to control Claude Code sessions through the SDK
- [[streaming-vs-single-mode|Streaming Input]] - Understanding the two input modes for Claude Agent SDK and when to use each
- [[subagents|Subagents in the SDK]] - Working with subagents in the Claude Agent SDK
- [[todo-tracking|Todo Lists]] - Track and display todos using the Claude Agent SDK for organized task management
- [[cost-tracking|Tracking Costs and Usage]] - Understand and track token usage for billing in the Claude Agent SDK

## General

- [[administration-api|Admin API overview]]
- [[beta-headers|Beta headers]] - Documentation for using beta headers with the Claude API
- [[canceling-message-batches|Cancel a Message Batch]] - Batches may be canceled any time before processing ends. Once cancellation is initiated, the batch enters a `canceling` state, at which time the system may complete any in-progress, non-interruptible requests before finalizing cancellation.
- [[claude-code-analytics-api|Claude Code Analytics API]] - Programmatically access your organization's Claude Code usage analytics and productivity metrics with the Claude Code Analytics Admin API.
- [[claude-on-amazon-bedrock|Claude on Amazon Bedrock]] - Anthropic's Claude models are now generally available through Amazon Bedrock.
- [[claude-on-vertex-ai|Claude on Vertex AI]] - Anthropic's Claude models are now generally available through [Vertex AI](https://cloud.google.com/vertex-ai).
- [[client-sdks|Client SDKs]] - We provide client libraries in a number of popular languages that make it easier to work with the Claude API.
- [[messages-count-tokens|Count Message tokens]] - Count the number of tokens in a Message.
- [[files-create|Create a File]] - Upload a file
- [[creating-message-batches|Create a Message Batch]] - Send a batch of Message creation requests.
- [[files-delete|Delete a File]] - Make a file inaccessible through the API
- [[deleting-message-batches|Delete a Message Batch]] - Delete a Message Batch.
- [[files-content|Download a File]] - Download the contents of a Claude generated file
- [[errors|Errors]]
- [[prompt-tools-generate|Generate a prompt]] - Generate a well-written prompt
- [[files-metadata|Get File Metadata]]
- [[models|Get a Model]] - Get a specific model.
- [[ip-addresses|IP addresses]] - Anthropic services use fixed IP addresses for both inbound and outbound connections. You can use these addresses to configure your firewall rules for secure access to the Claude API and Console. These addresses will not change without notice.
- [[prompt-tools-improve|Improve a prompt]] - Create a new-and-improved prompt guided by feedback
- [[files-list|List Files]] - List files within a workspace
- [[listing-message-batches|List Message Batches]] - List all Message Batches within a Workspace. Most recently created batches are returned first.
- [[models-list|List Models]] - List available models.
- [[messages|Messages]] - Send a structured list of input messages with text and/or image content, and the model will generate the next message in the conversation.
- [[migrating-from-text-completions-to-messages|Migrating from Text Completions]] - Migrating from Text Completions to Messages
- [[openai-sdk|OpenAI SDK compatibility]] - Anthropic provides a compatibility layer that enables you to use the OpenAI SDK to test the Claude API. With a few code changes, you can quickly evaluate Anthropic model capabilities.
- [[overview|Overview]]
- [[rate-limits|Rate limits]] - To mitigate misuse and manage capacity on our API, we have implemented limits on how much an organization can use the Claude API.
- [[retrieving-message-batch-results|Retrieve Message Batch Results]] - Streams the results of a Message Batch as a `.jsonl` file.
- [[retrieving-message-batches|Retrieve a Message Batch]] - This endpoint is idempotent and can be used to poll for Message Batch completion. To access the results of a Message Batch, make a request to the `results_url` field in the response.
- [[service-tiers|Service tiers]] - Different tiers of service allow you to balance availability, performance, and predictable costs based on your application's needs.
- [[supported-regions|Supported regions]] - Here are the countries, regions, and territories we can currently support access from:
- [[prompt-tools-templatize|Templatize a prompt]] - Templatize a prompt by indentifying and extracting variables
- [[usage-cost-api|Usage and Cost API]] - Programmatically access your organization's API usage and cost data with the Usage & Cost Admin API.
- [[skills-guide|Using Agent Skills with the API]] - Learn how to use Agent Skills to extend Claude's capabilities through the API.
- [[versioning|Versions]] - When making API requests, you must send an `anthropic-version` request header. For example, `anthropic-version: 2023-06-01`. If you are using our [[client-sdks|client SDKs]], this is handled for you automatically.

## Skills

- [[create-skill|Create Skill]]
- [[create-skill-version|Create Skill Version]]
- [[delete-skill|Delete Skill]]
- [[delete-skill-version|Delete Skill Version]]
- [[get-skill|Get Skill]]
- [[get-skill-version|Get Skill Version]]
- [[list-skill-versions|List Skill Versions]]
- [[list-skills|List Skills]]

## All api Pages

```dataview
TABLE description, subcategory
FROM #api
WHERE type != "moc"
SORT file.name
```
