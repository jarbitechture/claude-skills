---
created: 2025-11-05
modified: 2025-11-05
title: "Create Skill"
url: https://docs.claude.com/en/api/skills/create-skill
category: api
subcategory: skills
tags:
  - api
  - skills
related:
  - '[[create-skill-version]]'
  - '[[delete-skill]]'
  - '[[delete-skill-version]]'
  - '[[get-skill]]'
  - '[[get-skill-version]]'
---

# Create Skill

post /v1/skills

---

**Source:** [Official Documentation](https://docs.claude.com/en/api/skills/create-skill)
