---
created: 2025-11-05
modified: 2025-11-05
title: "Delete Skill"
url: https://docs.claude.com/en/api/skills/delete-skill
category: api
subcategory: skills
tags:
  - api
  - skills
related:
  - '[[create-skill]]'
  - '[[create-skill-version]]'
  - '[[delete-skill-version]]'
  - '[[get-skill]]'
  - '[[get-skill-version]]'
---

# Delete Skill

delete /v1/skills/{skill_id}

---

**Source:** [Official Documentation](https://docs.claude.com/en/api/skills/delete-skill)
