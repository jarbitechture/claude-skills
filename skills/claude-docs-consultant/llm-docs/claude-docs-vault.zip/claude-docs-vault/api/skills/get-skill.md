---
created: 2025-11-05
modified: 2025-11-05
title: "Get Skill"
url: https://docs.claude.com/en/api/skills/get-skill
category: api
subcategory: skills
tags:
  - api
  - skills
related:
  - '[[create-skill]]'
  - '[[create-skill-version]]'
  - '[[delete-skill]]'
  - '[[delete-skill-version]]'
  - '[[get-skill-version]]'
---

# Get Skill

get /v1/skills/{skill_id}

---

**Source:** [Official Documentation](https://docs.claude.com/en/api/skills/get-skill)
