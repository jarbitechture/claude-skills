---
created: 2025-11-05
modified: 2025-11-05
title: "Create Skill Version"
url: https://docs.claude.com/en/api/skills/create-skill-version
category: api
subcategory: skills
tags:
  - api
  - skills
related:
  - '[[create-skill]]'
  - '[[delete-skill]]'
  - '[[delete-skill-version]]'
  - '[[get-skill]]'
  - '[[get-skill-version]]'
---

# Create Skill Version

post /v1/skills/{skill_id}/versions

---

**Source:** [Official Documentation](https://docs.claude.com/en/api/skills/create-skill-version)
