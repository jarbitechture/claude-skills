---
created: 2025-11-05
modified: 2025-11-05
type: moc
category: release-notes
tags:
  - moc
  - release-notes
  - index
---

# Release Notes - Index

> [!abstract] Overview
> Index for **release-notes** documentation
> 2 pages across 1 sections

## General

- [[overview|Claude Developer Platform]] - Updates to the Claude Developer Platform, including the Claude API, client SDKs, and the Claude Console.
- [[system-prompts|System Prompts]] - See updates to the core system prompts on [Claude.ai](https://www.claude.ai) and the Claude [iOS](http://anthropic.com/ios) and [Android](http://anthropic.com/android) apps.

## All release-notes Pages

```dataview
TABLE description, subcategory
FROM #release-notes
WHERE type != "moc"
SORT file.name
```
