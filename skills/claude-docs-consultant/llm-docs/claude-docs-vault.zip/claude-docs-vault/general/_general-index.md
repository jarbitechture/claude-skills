---
created: 2025-11-05
modified: 2025-11-05
type: moc
category: general
tags:
  - moc
  - general
  - index
---

# General - Index

> [!abstract] Overview
> Index for **general** documentation
> 1 pages across 1 sections

## General

- [[home|null]]

## All general Pages

```dataview
TABLE description, subcategory
FROM #general
WHERE type != "moc"
SORT file.name
```
