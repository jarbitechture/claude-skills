---
created: 2025-11-05
modified: 2025-11-05
type: moc
tags:
  - index
  - moc
  - claude
aliases:
  - Home
---

# Claude Documentation Vault

> [!info] Welcome
> Complete English documentation for Claude, Claude Code, and APIs
>
> **269** pages | **5** categories

## Categories

### [[_api-index|Api]]
84 pages

### [[_docs-index|Docs]]
116 pages

### [[_general-index|General]]
1 pages

### [[_release-notes-index|Release Notes]]
2 pages

### [[_resources-index|Resources]]
66 pages

## Stats

```dataview
TABLE length(rows) as Pages
FROM ""
WHERE type != "moc"
GROUP BY category
SORT length(rows) DESC
```
