---
created: 2025-11-05
modified: 2025-11-05
type: moc
category: docs
tags:
  - moc
  - docs
  - index
---

# Docs - Index

> [!abstract] Overview
> Index for **docs** documentation
> 116 pages across 6 sections

## About Claude

- [[choosing-a-model|Choosing the right model]] - Selecting the optimal Claude model for your application involves balancing three key considerations: capabilities, speed, and cost. This guide helps you make an informed decision based on your specific requirements.
- [[content-moderation|Content moderation]] - Content moderation is a critical aspect of maintaining a safe, respectful, and productive environment in digital applications. In this guide, we'll discuss how Claude can be used to moderate content within your digital application.
- [[customer-support-chat|Customer support agent]] - This guide walks through how to leverage Claude's advanced conversational capabilities to handle customer inquiries in real time, providing 24/7 support, reducing wait times, and managing high support volumes with accurate responses and positive interactions.
- [[glossary|Glossary]] - These concepts are not unique to Anthropic’s language models, but we present a brief summary of key terms below.
- [[overview|Guides to common use cases]]
- [[legal-summarization|Legal summarization]] - This guide walks through how to leverage Claude's advanced natural language processing capabilities to efficiently summarize legal documents, extracting key information and expediting legal research. With Claude, you can streamline the review of contracts, litigation prep, and regulatory work, saving time and ensuring accuracy in your legal processes.
- [[migrating-to-claude-4|Migrating to Claude 4.5]]
- [[model-deprecations|Model deprecations]]
- [[overview|Models overview]] - Claude is a family of state-of-the-art large language models developed by Anthropic. This guide introduces our models and compares their performance.
- [[pricing|Pricing]] - Learn about Anthropic's pricing structure for models and features
- [[ticket-routing|Ticket routing]] - This guide walks through how to harness Claude's advanced natural language understanding capabilities to classify customer support tickets at scale based on customer intent, urgency, prioritization, customer profile, and more.
- [[whats-new-claude-4-5|What's new in Claude 4.5]]

## Agents And Tools

- [[overview|Agent Skills]] - Agent Skills are modular capabilities that extend Claude's functionality. Each Skill packages instructions, metadata, and optional resources (scripts, templates) that Claude uses automatically when relevant.
- [[bash-tool|Bash tool]]
- [[code-execution-tool|Code execution tool]]
- [[computer-use-tool|Computer use tool]]
- [[fine-grained-tool-streaming|Fine-grained tool streaming]]
- [[quickstart|Get started with Agent Skills in the API]] - Learn how to use Agent Skills to create documents with the Claude API in under 10 minutes.
- [[claude-for-sheets|Google Sheets add-on]] - The [Claude for Sheets extension](https://workspace.google.com/marketplace/app/claude%5Ffor%5Fsheets/909417792257) integrates Claude into Google Sheets, allowing you to execute interactions with Claude directly in cells.
- [[implement-tool-use|How to implement tool use]]
- [[mcp-connector|MCP connector]]
- [[memory-tool|Memory tool]]
- [[remote-mcp-servers|Remote MCP servers]]
- [[best-practices|Skill authoring best practices]] - Learn how to write effective Skills that Claude can discover and use successfully.
- [[text-editor-tool|Text editor tool]]
- [[token-efficient-tool-use|Token-efficient tool use]]
- [[overview|Tool use with Claude]]
- [[web-fetch-tool|Web fetch tool]]
- [[web-search-tool|Web search tool]]

## Build With Claude

- [[prompt-generator|Automatically generate first draft prompt templates]]
- [[batch-processing|Batch processing]]
- [[be-clear-and-direct|Be clear, direct, and detailed]]
- [[extended-thinking|Building with extended thinking]]
- [[chain-prompts|Chain complex prompts for stronger performance]]
- [[citations|Citations]]
- [[context-editing|Context editing]] - Automatically manage conversation context as it grows with context editing.
- [[context-windows|Context windows]]
- [[embeddings|Embeddings]] - Text embeddings are numerical representations of text that enable measuring semantic similarity. This guide introduces embeddings, their applications, and how to use embedding models for tasks like search, recommendations, and anomaly detection.
- [[extended-thinking-tips|Extended thinking tips]]
- [[overview|Features overview]] - Explore Claude's advanced features and capabilities.
- [[files|Files API]]
- [[system-prompts|Giving Claude a role with a system prompt]]
- [[chain-of-thought|Let Claude think (chain of thought prompting) to increase performance]]
- [[long-context-tips|Long context prompting tips]]
- [[multilingual-support|Multilingual support]] - Claude excels at tasks across multiple languages, maintaining strong cross-lingual performance relative to English.
- [[pdf-support|PDF support]] - Process PDFs with Claude. Extract text, analyze charts, and understand visual content from your documents.
- [[prefill-claudes-response|Prefill Claude's response for greater output control]]
- [[prompt-caching|Prompt caching]]
- [[overview|Prompt engineering overview]]
- [[claude-4-best-practices|Prompting best practices]]
- [[search-results|Search results]] - Enable natural citations for RAG applications by providing search results with source attribution
- [[streaming|Streaming Messages]]
- [[token-counting|Token counting]]
- [[use-xml-tags|Use XML tags to structure your prompts]]
- [[multishot-prompting|Use examples (multishot prompting) to guide Claude's behavior]]
- [[prompt-improver|Use our prompt improver to optimize your prompts]]
- [[prompt-templates-and-variables|Use prompt templates and variables]]
- [[vision|Vision]] - The Claude 3 and 4 families of models comes with new vision capabilities that allow Claude to understand and analyze images, opening up exciting possibilities for multimodal interaction.
- [[working-with-messages|Working with the Messages API]] - Practical patterns and examples for using the Messages API effectively

## Claude Code

- [[skills|Agent Skills]] - Create, manage, and share Skills to extend Claude's capabilities in Claude Code.
- [[analytics|Analytics]] - View detailed usage insights and productivity metrics for your organization's Claude Code deployment.
- [[cli-reference|CLI reference]] - Complete reference for Claude Code command-line interface, including commands and flags.
- [[checkpointing|Checkpointing]] - Automatically track and rewind Claude's edits to quickly recover from unwanted changes.
- [[github-actions|Claude Code GitHub Actions]] - Learn about integrating Claude Code into your development workflow with Claude Code GitHub Actions
- [[gitlab-ci-cd|Claude Code GitLab CI/CD]] - Learn about integrating Claude Code into your development workflow with GitLab CI/CD
- [[amazon-bedrock|Claude Code on Amazon Bedrock]] - Learn about configuring Claude Code through Amazon Bedrock, including setup, IAM configuration, and troubleshooting.
- [[google-vertex-ai|Claude Code on Google Vertex AI]] - Learn about configuring Claude Code through Google Vertex AI, including setup, IAM configuration, and troubleshooting.
- [[claude-code-on-the-web|Claude Code on the web]] - Run Claude Code tasks asynchronously on secure cloud infrastructure
- [[overview|Claude Code overview]] - Learn about Claude Code, Anthropic's agentic coding tool that lives in your terminal and helps you turn ideas into code faster than ever before.
- [[settings|Claude Code settings]] - Configure Claude Code with global and project-level settings, and environment variables.
- [[common-workflows|Common workflows]] - Learn about common workflows with Claude Code.
- [[mcp|Connect Claude Code to tools via MCP]] - Learn how to connect Claude Code to your tools with the Model Context Protocol.
- [[data-usage|Data usage]] - Learn about Anthropic's data usage policies for Claude
- [[devcontainer|Development containers]] - Learn about the Claude Code development container for teams that need consistent, secure environments.
- [[third-party-integrations|Enterprise deployment overview]] - Learn how Claude Code can integrate with various third-party services and infrastructure to meet enterprise deployment requirements.
- [[network-config|Enterprise network configuration]] - Configure Claude Code for enterprise environments with proxy servers, custom Certificate Authorities (CA), and mutual Transport Layer Security (mTLS) authentication.
- [[hooks-guide|Get started with Claude Code hooks]] - Learn how to customize and extend Claude Code's behavior by registering shell commands
- [[headless|Headless mode]] - Run Claude Code programmatically without interactive UI
- [[hooks|Hooks reference]] - This page provides reference documentation for implementing hooks in Claude Code.
- [[iam|Identity and Access Management]] - Learn how to configure user authentication, authorization, and access controls for Claude Code in your organization.
- [[interactive-mode|Interactive mode]] - Complete reference for keyboard shortcuts, input modes, and interactive features in Claude Code sessions.
- [[jetbrains|JetBrains IDEs]] - Use Claude Code with JetBrains IDEs including IntelliJ, PyCharm, WebStorm, and more
- [[llm-gateway|LLM gateway configuration]] - Learn how to configure Claude Code with LLM gateway solutions, including LiteLLM setup, authentication methods, and enterprise features like usage tracking and budget management.
- [[legal-and-compliance|Legal and compliance]] - Legal agreements, compliance certifications, and security information for Claude Code.
- [[memory|Manage Claude's memory]] - Learn how to manage Claude Code's memory across sessions with different memory locations and best practices.
- [[costs|Manage costs effectively]] - Learn how to track and optimize token usage and costs when using Claude Code.
- [[migration-guide|Migrate to Claude Agent SDK]] - Guide for migrating the Claude Code TypeScript and Python SDKs to the Claude Agent SDK
- [[model-config|Model configuration]] - Learn about the Claude Code model configuration, including model aliases like `opusplan`
- [[monitoring-usage|Monitoring]] - Learn how to enable and configure OpenTelemetry for Claude Code.
- [[terminal-config|Optimize your terminal setup]] - Claude Code works best when your terminal is properly configured. Follow these guidelines to optimize your experience.
- [[output-styles|Output styles]] - Adapt Claude Code for uses beyond software engineering
- [[plugin-marketplaces|Plugin marketplaces]] - Create and manage plugin marketplaces to distribute Claude Code extensions across teams and communities.
- [[plugins|Plugins]] - Extend Claude Code with custom commands, agents, hooks, Skills, and MCP servers through the plugin system.
- [[plugins-reference|Plugins reference]] - Complete technical reference for Claude Code plugin system, including schemas, CLI commands, and component specifications.
- [[quickstart|Quickstart]] - Welcome to Claude Code!
- [[sandboxing|Sandboxing]] - Learn how Claude Code's sandboxed bash tool provides filesystem and network isolation for safer, more autonomous agent execution.
- [[security|Security]] - Learn about Claude Code's security safeguards and best practices for safe usage.
- [[setup|Set up Claude Code]] - Install, authenticate, and start using Claude Code on your development machine.
- [[slash-commands|Slash commands]] - Control Claude's behavior during an interactive session with slash commands.
- [[statusline|Status line configuration]] - Create a custom status line for Claude Code to display contextual information
- [[sub-agents|Subagents]] - Create and use specialized AI subagents in Claude Code for task-specific workflows and improved context management.
- [[troubleshooting|Troubleshooting]] - Discover solutions to common issues with Claude Code installation and usage.
- [[vs-code|Visual Studio Code]] - Use Claude Code with Visual Studio Code through our native extension or CLI integration

## General

- [[get-started|Get started with Claude]] - Make your first API call to Claude and build a simple web search assistant
- [[intro|Intro to Claude]] - Claude is a highly performant, trustworthy, and intelligent AI platform built by Anthropic. Claude excels at tasks involving language, reasoning, analysis, coding, and more.
- [[mcp|Model Context Protocol (MCP)]]

## Test And Evaluate

- [[develop-tests|Create strong empirical evaluations]]
- [[define-success|Define your success criteria]]
- [[increase-consistency|Increase output consistency (JSON mode)]]
- [[keep-claude-in-character|Keep Claude in character with role prompting and prefilling]]
- [[mitigate-jailbreaks|Mitigate jailbreaks and prompt injections]]
- [[reduce-hallucinations|Reduce hallucinations]]
- [[reduce-prompt-leak|Reduce prompt leak]]
- [[reduce-latency|Reducing latency]]
- [[handle-streaming-refusals|Streaming refusals]]
- [[eval-tool|Using the Evaluation Tool]] - The [Claude Console](https://console.anthropic.com/dashboard) features an **Evaluation tool** that allows you to test your prompts under various scenarios.

## All docs Pages

```dataview
TABLE description, subcategory
FROM #docs
WHERE type != "moc"
SORT file.name
```
